# inviter_core.py
import os
import asyncio
from pyrogram import Client
from pyrogram.errors import (
    PeerIdInvalid, UsernameInvalid, UsernameNotOccupied,
    UserAlreadyParticipant, UserPrivacyRestricted, FloodWait
)
import config # Импортируем настройки
import utils # Импортируем утилиты

class TelegramInviter:
    def __init__(self, api_id, api_hash, session_name, invite_link, progress_file):
        """
        Инициализирует класс TelegramInviter.
        Все основные настройки берутся из config.py.
        """
        self.app = Client(session_name, api_id, api_hash)
        self.invite_link = invite_link
        self.progress_file = progress_file
        
        # Настройки задержек и размеров чанков из конфига
        self.current_delay = config.INITIAL_DELAY_SECONDS
        self.delay_increment = config.DELAY_INCREMENT_SECONDS
        self.max_delay = config.MAX_DELAY_SECONDS
        self.chunk_size = config.CHUNK_SIZE
        self.chunk_pause = config.CHUNK_PAUSE_SECONDS

        # Переменные для отслеживания прогресса внутри текущей сессии
        self.skipped_users_current_session = [] # Пользователи, пропущенные в текущей сессии
        self.total_processed_users_set = set() # Все обработанные пользователи за всю историю (для сохранения)

    async def _get_chat_info(self):
        """
        Получает информацию о целевом чате и проверяет права бота на приглашение.
        :return: Объект чата Pyrogram.
        :raises ValueError: Если INVITE_LINK не задан или у бота нет прав.
        """
        print(f"🔗 Подключаемся к чату: {self.invite_link}")
        if not self.invite_link:
            raise ValueError("Параметр 'INVITE_LINK' не задан.")
        
        chat = await self.app.get_chat(self.invite_link)
        
        me_in_chat = await self.app.get_chat_member(chat.id, "me")
        if not me_in_chat.privileges or not me_in_chat.privileges.can_invite_users:
            raise ValueError("💢 У бота НЕТ прав на приглашение пользователей в этот чат! Проверьте настройки администратора.")
        
        print(f"✅ Бот успешно подключен к чату '{chat.title}' и имеет права на приглашение.")
        return chat

    async def _process_chunk(self, chat, usernames_chunk):
        """
        Обрабатывает приглашения для одной порции пользователей.
        Пытается добавить каждого пользователя в чат, обрабатывает различные ошибки.
        :param chat: Объект чата Pyrogram, куда будут приглашаться пользователи.
        :param usernames_chunk: Список юзернеймов для обработки в текущей порции.
        :return: Кортеж: (количество_успешных, количество_пропущенных, количество_ошибок, список_обработанных_в_этом_чанке)
        """
        success = skipped = failed = 0
        processed_in_this_chunk = [] # Пользователи, обработанные в текущей порции
        
        for idx, username in enumerate(usernames_chunk, 1):
            try:
                print(f"\n🔹 Обрабатываем {idx}/{len(usernames_chunk)}: @{username}")
                
                user = await self.app.get_users(username) # Получаем объект пользователя по юзернейму
                
                # Проверяем, не является ли пользователь уже участником чата
                try:
                    member = await self.app.get_chat_member(chat.id, user.id)
                    if member.status in ["member", "administrator", "creator"]:
                        print(f"⏩ @{username} уже в чате. Пропускаем.")
                        skipped += 1
                        self.skipped_users_current_session.append(username) # Добавляем в список пропущенных
                        processed_in_this_chunk.append(username) # Отмечаем как обработанного
                        continue # Переходим к следующему пользователю
                except Exception:
                    # Если get_chat_member выдал ошибку (например, пользователь не найден в чате),
                    # это означает, что его нет в чате, и можно попробовать пригласить.
                    pass 
                
                await self.app.add_chat_members(chat.id, user.id) # Приглашаем пользователя в чат
                success += 1
                processed_in_this_chunk.append(username) # Отмечаем как успешно обработанного
                print(f"✅ УСПЕШНО приглашен @{username}")
                
                delay_to_use = self.current_delay 
                print(f"⏳ Ждем {delay_to_use} секунд перед следующим приглашением...")
                await asyncio.sleep(delay_to_use) # Пауза перед следующим действием
                
            except FloodWait as e:
                # Обработка ошибки FloodWait: Telegram просит подождать определенное время
                print(f"⚠️ ОБНАРУЖЕН FLOOD WAIT! Ждем {e.value} секунд.")
                processed_in_this_chunk.append(username) # Пользователь считается обработанным, чтобы не повторять
                await asyncio.sleep(e.value) # Ждем указанное Telegram время
                self.current_delay = min(self.current_delay + self.delay_increment, self.max_delay) # Увеличиваем задержку
                print(f"Задержка увеличена до {self.current_delay} секунд.")
                # Прогресс будет сохранен после обработки всей порции в run_invitation
            except UserAlreadyParticipant:
                # Пользователь уже является участником чата (повторная проверка или гонка условий)
                print(f"⏭ @{username} уже участник чата.")
                skipped += 1
                self.skipped_users_current_session.append(username)
                processed_in_this_chunk.append(username)
            except UserPrivacyRestricted:
                # Пользователь имеет ограничения приватности, не позволяет себя добавлять
                print(f"⏭ @{username} имеет ограничения приватности. Невозможно пригласить.")
                skipped += 1
                self.skipped_users_current_session.append(username)
                processed_in_this_chunk.append(username)
            except (PeerIdInvalid, UsernameInvalid, UsernameNotOccupied):
                # Юзернейм неверный, пользователь не найден или не существует
                print(f"❌ @{username}: Неверный ID пользователя / юзернейм не найден.")
                failed += 1
                processed_in_this_chunk.append(username)
            except Exception as e:
                # Любая другая непредвиденная ошибка
                print(f"❌ Непредвиденная ошибка при обработке @{username}: {type(e).__name__} - {e}")
                failed += 1
                processed_in_this_chunk.append(username)
        
        return success, skipped, failed, processed_in_this_chunk

    async def run_invitation(self, usernames_to_process, last_chunk_processed, initial_processed_users, initial_skipped_users):
        """
        Запускает основной процесс приглашения пользователей.
        :param usernames_to_process: Список юзернеймов для обработки.
        :param last_chunk_processed: Индекс последней обработанной порции (для возобновления).
        :param initial_processed_users: Список пользователей, уже обработанных из файла прогресса.
        :param initial_skipped_users: Список пользователей, уже пропущенных из файла прогресса.
        """
        # Инициализируем общий набор обработанных пользователей и список пропущенных
        # данными из файла прогресса.
        self.total_processed_users_set.update(initial_processed_users)
        self.skipped_users_current_session.extend(initial_skipped_users)
        self.skipped_users_current_session = list(set(self.skipped_users_current_session)) # Уникальные значения

        async with self.app: # Автоматическое закрытие клиента после завершения работы
            try:
                chat = await self._get_chat_info() # Получаем инфо о чате и проверяем права бота

                total_chunks = (len(usernames_to_process) + self.chunk_size - 1) // self.chunk_size
                print(f"Начинаем обработку {len(usernames_to_process)} пользователей в {total_chunks} порциях по {self.chunk_size} человек.")

                start_index_for_chunks = last_chunk_processed * self.chunk_size
                
                # Цикл по порциям пользователей
                for i in range(start_index_for_chunks, len(usernames_to_process), self.chunk_size):
                    chunk = usernames_to_process[i:i+self.chunk_size]
                    current_chunk_number = (i // self.chunk_size) + 1 # Нумерация порций с 1
                    
                    print(f"\n📦 Обработка порции {current_chunk_number}/{total_chunks} (пользователи {i+1}-{min(i+len(chunk), len(usernames_to_process))})")
                    
                    # Запускаем обработку приглашений для текущей порции
                    successes, skips, fails, processed_in_current_chunk = await self._process_chunk(chat, chunk)
                    
                    # Добавляем пользователей, обработанных в этой порции, к общему набору обработанных
                    self.total_processed_users_set.update(processed_in_current_chunk)
                    
                    # Сохраняем прогресс после каждой порции.
                    # Преобразуем наборы (set) в списки для сохранения в JSON.
                    utils.save_progress(
                        list(self.total_processed_users_set), 
                        list(set(self.skipped_users_current_session)), # Убедимся, что пропущенные тоже уникальны
                        self.current_delay, 
                        current_chunk_number, 
                        self.progress_file
                    )
                    
                    print(f"\n📊 Результаты по текущей порции: Успешно: {successes}, Пропущено: {skips}, Ошибки: {fails}")

                    # Пауза между чанками, если это не последняя порция
                    if i + self.chunk_size < len(usernames_to_process):
                        print(f"⏸ Пауза между порциями: {self.chunk_pause} секунд ({(self.chunk_pause / 60):.0f} минут)...")
                        await asyncio.sleep(self.chunk_pause)
                
                print("\n🏁 ВСЕ ПОЛЬЗОВАТЕЛИ ОБРАБОТАНЫ! 🏁")
                if os.path.exists(self.progress_file):
                    os.remove(self.progress_file)
                    print(f"🗑 Файл прогресса '{self.progress_file}' удален, так как работа завершена.")
                    
            except ValueError as e:
                print(f"💥 Ошибка конфигурации или прав: {e}")
            except Exception as e:
                print(f"💥 ФАТАЛЬНАЯ ОШИБКА: {type(e).__name__} - {e}")
            finally:
                # Выводим общее количество пропущенных пользователей в конце
                if self.skipped_users_current_session:
                    print(f"\n📝 Всего пропущено пользователей за всю сессию: {len(set(self.skipped_users_current_session))}")