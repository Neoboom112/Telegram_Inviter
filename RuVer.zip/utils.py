# utils.py

import json
import os
import csv
import requests
import time
import config # Импортируем наш файл с настройками

# --- Функции для работы с прогрессом и CSV ---

def load_progress(progress_file):
    """
    Загружает прогресс выполнения из файла.
    Если файл существует и корректен, возвращает его содержимое.
    В случае ошибки или отсутствия файла, возвращает начальные значения прогресса
    из настроек.
    """
    if os.path.exists(progress_file):
        try:
            with open(progress_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError as e:
            print(f"⚠️ Ошибка декодирования JSON при загрузке прогресса: {e}. Файл может быть поврежден.")
        except Exception as e:
            print(f"⚠️ Непредвиденная ошибка при загрузке прогресса: {e}")
    # Возвращаем начальные значения, если файл не найден или произошла ошибка
    return {
        'processed': [], # Список пользователей, которые уже были обработаны
        'skipped': [],   # Список пользователей, которые были пропущены
        'current_delay': config.INITIAL_DELAY_SECONDS, # Начальное значение задержки
        'last_chunk': 0      # Индекс последней обработанной порции
    }

def save_progress(processed, skipped, delay, last_chunk, progress_file):
    """
    Сохраняет текущий прогресс работы скрипта в файл.
    :param processed: Список всех пользователей, которые были обработаны за всю сессию.
    :param skipped: Список всех пользователей, которые были пропущены за всю сессию.
    :param delay: Текущее значение задержки между приглашениями.
    :param last_chunk: Номер последней полностью обработанной порции.
    :param progress_file: Путь к файлу прогресса.
    """
    progress = {
        'processed': processed,
        'skipped': skipped,
        'current_delay': delay,
        'last_chunk': last_chunk,
        'timestamp': int(time.time()) # Отметка времени последнего сохранения
    }
    try:
        with open(progress_file, 'w', encoding='utf-8') as f:
            json.dump(progress, f, indent=4) # Запись в JSON с отступами для читаемости
    except Exception as e:
        print(f"⚠️ Ошибка при сохранении прогресса: {e}")

def get_usernames_from_csv(csv_url, processed_from_file_set):
    """
    Загружает список юзернеймов из CSV-файла по указанному URL.
    Фильтрует список, исключая пользователей, которые уже были обработаны.
    :param csv_url: URL CSV-файла.
    :param processed_from_file_set: Набор (set) пользователей, которые уже были обработаны.
    :return: Список юзернеймов для обработки.
    """
    try:
        print("🌐 Загружаем список пользователей из CSV-файла...")
        if not csv_url or not csv_url.startswith("http"):
            raise ValueError("URL CSV-файла не задан или не является валидной HTTP-ссылкой.")
        
        response = requests.get(csv_url)
        response.raise_for_status() # Вызывает исключение для ошибок HTTP (4xx, 5xx)
        
        print("🔍 Разбираем CSV-данные...")
        csv_reader = csv.reader(response.text.splitlines())
        all_usernames = []
        
        for row in csv_reader:
            if row: # Проверяем, что строка не пустая
                username = row[0].strip().lstrip('@') # Удаляем пробелы и символ '@'
                if username and username.lower() != "username": # Пропускаем строку заголовка "username"
                    all_usernames.append(username)

        # Фильтруем список, оставляя только тех, кто еще не был обработан
        usernames_to_process = [u for u in all_usernames if u not in processed_from_file_set]
        
        print(f"📊 Всего пользователей в CSV: {len(all_usernames)} | Ранее обработано: {len(processed_from_file_set)} | Осталось обработать: {len(usernames_to_process)}")
        return usernames_to_process
        
    except requests.exceptions.RequestException as e:
        print(f"💥 Ошибка загрузки CSV по URL '{csv_url}': {e}")
        return []
    except ValueError as e:
        print(f"💥 Ошибка конфигурации: {e}")
        return []
    except Exception as e:
        print(f"💥 Непредвиденная ошибка при чтении CSV: {e}")
        return []