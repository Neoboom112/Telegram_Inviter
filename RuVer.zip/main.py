# main.py

import asyncio
import os
import config # Импортируем настройки
import utils # Импортируем утилиты
from inviter_core import TelegramInviter # Импортируем наш класс TelegramInviter

async def main():
    """
    Основная функция, управляющая запуском бота-приглашателя.
    """
    print("\n🚀 ЗАПУСК БОТА 🚀")

    # 1. Загружаем прогресс из файла
    progress = utils.load_progress(config.PROGRESS_FILE)
    
    # 2. Получаем список пользователей для обработки, учитывая уже обработанных
    # Передаем set из обработанных пользователей для быстрой фильтрации
    usernames_to_process = utils.get_usernames_from_csv(
        config.CSV_URL, 
        set(progress.get('processed', []))
    )
    
    # Если список пользователей пуст, завершаем работу
    if not usernames_to_process:
        print("💢 Список пользователей пуст или все уже обработаны. Завершение работы.")
        if os.path.exists(config.PROGRESS_FILE):
            os.remove(config.PROGRESS_FILE)
            print(f"🗑 Файл прогресса '{config.PROGRESS_FILE}' удален.")
        return

    # 3. Инициализируем инвайтер, передавая ему все необходимые настройки
    inviter = TelegramInviter(
        api_id=config.API_ID,
        api_hash=config.API_HASH,
        session_name=config.SESSION_NAME,
        invite_link=config.INVITE_LINK,
        progress_file=config.PROGRESS_FILE
    )

    # 4. Запускаем процесс приглашения
    await inviter.run_invitation(
        usernames_to_process,
        progress.get('last_chunk', 0), # Начальная порция для возобновления
        progress.get('processed', []), # Ранее обработанные пользователи
        progress.get('skipped', [])    # Ранее пропущенные пользователи
    )

    print("\n🎯 РАБОТА ЗАВЕРШЕНА 🎯")

if __name__ == "__main__":
    # Запускаем асинхронную главную функцию
    asyncio.run(main())